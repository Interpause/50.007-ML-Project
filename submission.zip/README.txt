# Group 18 - Judo

Hi there, the code is in `ALL_TASKS.ipynb`. It assumes you are already running
some Jupyter Lab, and will `%pip` install the required dependencies. The data is
already in `data/` for you.

## Folder Structure

- `data/`: The data downloaded from the 2025 Kaggle.
- `*.csv`: The various CSV submissions required by Tasks 1, 2 and 3.
  - `Optimized_TFIDF_LR_Prediction.csv`: Our task 3 submission.

## TODO

- Report
- All our other codes

## Stuff we Tried

Due to time limitations, we aren't including them into the zip folder for now as
we spent up to the last minute trying new approaches. Below is the list of codes
we will include with the final submission on 12th Aug.

- XGBoost (Gradient Boosted Tree) with PCA
- XGBoost Gradient-boosted Random Forest
- XGBoost with SVD (to do LSA instead) and Optuna hyperparameter sweep
- KFold Cross-Validation Ensemble of Gradient Boosted Trees with Optuna-derived hyperparameters
- Each of the follow models/library invidually, then combined into a layered ensemble:
  - XGBoost
  - Support Vector Machine
  - LightGBM
  - Catboost
  - Logistic Regression
  - Random Forest
  - Naive Bayes

And in the end, Logistic Regression with custom TF-IDF was the best. We did try
custom TF-IDF we some of the above models (notably KFold XGBoost), but it didn't
perform better.
